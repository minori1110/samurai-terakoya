const stripe = Stripe('pk_test_51RW9xFRqBlyJLIlRvMLXOKkz3zZvJdeyQpyjG3dc3cPl9ZtZPgZXwBlcTxSOOdvCVdrrkC1fjGKxk6QefdzYtnRS00vlixoXXV');
const paymentButton = document.querySelector('#paymentButton');

paymentButton.addEventListener('click', () => {
 stripe.redirectToCheckout({
   sessionId: sessionId
 })
});
